export const URL = "https://api.tfl.gov.uk/";
export const APIID = "11dc0537";
export const APIKEY = "d6de4da60528b126dd29673c21316586";
export const APIPARAMS = "?app_id=11dc0537&app_key=d6de4da60528b126dd29673c21316586";